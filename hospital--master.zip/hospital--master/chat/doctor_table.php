<?php

include('db.php');

?>


<!DOCTYPE html>

<html>

<head>
             <title>  doctor signup </title>
</head>

<body>

<form method = "POST">
    <p> name </p>
     <input type = "text" name = "name">
     </br>
     <p> doctor id </p>
     <input type = "number" name = "doctor_id">
     </br>
     <p> doctor type </p>
     <input type = "text" name = "doctor_type">
     </br>
     <p> submit </p>
     <input type = "submit" value = "submit" name = "submit">
     </form>
       <?php

     if(isset($_POST['submit'])){
         $name = $_POST['name'];
         $doctor_id = $_POST['doctor_id'];
         $doctor_type = $_POST['doctor_type'];
        
       echo "$name";
        
         $sql = "CREATE TABLE `ecommerce`.`{$name}` (
            id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
            doctor_name VARCHAR(30),
            doctor_id VARCHAR(30),
            doctor_type VARCHAR(70) 
        )";

if(mysqli_query($conn, $sql)){
    echo "Table created successfully.";
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($sql);
}


$query = "INSERT INTO doctor (doctor_name,doctor_id,doctor_type) VALUES ('$name','$doctor_id','$doctor_type')";
mysqli_query($conn,$query); 
     }

   ?>

   </html>