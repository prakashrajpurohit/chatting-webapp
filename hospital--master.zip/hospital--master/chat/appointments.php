<?php

include('db.php');

?>

<html>  
    <head> <!-- Meta tag Keywords -->
    <style>
body  {
  background-image: url("111.jpg");
  background-repeat: no-repeat;
  background-size: auto;
  background-position: center; /* Center the image */
  background-repeat: no-repeat; /* Do not repeat the image */
  background-size: cover;

}
</style>  
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="UTF-8" />
	<meta name="keywords" content="Latest Login Form Responsive Widget,Login form widgets, Sign up Web forms , Login signup Responsive web form,Flat Pricing table,Flat Drop downs,Registration Forms,News letter Forms,Elements" />
	<script>
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!-- Meta tag Keywords -->

	<!-- css files -->
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
	<!-- Style-CSS -->
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<!-- Font-Awesome-Icons-CSS -->
	<!-- //css files -->

	<!-- web-fonts -->
	<link href="//fonts.googleapis.com/css?family=Source+Sans+Pro:200,200i,300,300i,400,400i,600,600i,700,700i,900,900i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese"
	 rel="stylesheet">
	<!-- //web-fonts -->
   
        <title>Chat Application using PHP Ajax Jquery</title>  
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    </head>  
    <body>  
        <div class="container">
   <br />
   
   <h2 align="center"><a href="login.php"><img src="2.jpg"></a>  Easy Health Care Solutions </h2><br />
   <br>

<br>
		<!-- title -->
		<!-- //title -->
		<!-- content -->
		<div class="sub-main-w3">
			<div class="bg-content-w3pvt">
				<div class="top-content-style">
				</div>
				<form action="#" method="post">
					<p class="legend">Appointment<span class="fa fa-hand-o-down"></span></p>
					<div class="input">
						<input type="text" name="username" class="form-control" placeholder="Name" required />
					</div>
					<div class="input">
						<input type="number" name="number" class="form-control" placeholder="Phone_Number" required />
          </div>
          <div class="input">
						<input type="email" name="email" class="form-control" placeholder="Email" required />
          </div>
          <div class="input">
						<input type="text" name="text" class="form-control" placeholder="Doctor_Name" required />
					</div>
            <button type="submit"  name="login" class="btn submit">
						
						<span class="fa fa-sign-in"></span>
					</button>
					
				</form>
</a>
<br><br>

			</div>
		</div>
		<!-- //content -->
		<!-- copyright -->
		<div class="copyright">
			<h2>All rights reserved
			</h2>
		</div>
		<!-- //copyright -->
	</div>
</body>

<?php


if(isset($_POST['submit'])){
         $Name = $_POST['Name'];
         $Phone_Number = $_POST['Phone_Number'];
         $Email = $_POST['Email'];
         $Doctor_Name= $_POST['Doctor_Name'];
      //  $time_avail = $_POST['time_avail'];

         if($doc_name == 'dentist')   //form valuues in database
         {
             echo "dentist";
             $query = "INSERT INTO dentist (name,mob_number,email,doc_name,time) VALUES ('$Name','$Phone_Number','$Email','$Doctor_Name')";
             mysqli_query($conn,$query); 
         }

         else 
         {
             echo "select another";
		 }
		 





		 

		 $time = array("4","4:30","5","5:30","6");


     
		 $query ="SELECT * FROM dentist";
		 $data = mysqli_query($conn,$query);
		 
		 while($row = mysqli_fetch_array($data))
		 {
			 $time_taken = $row['time'];
		 
			 $time_taken1[] = $time_taken;
			// echo "$time_taken";
		 }
		 for($i=0;$i<5;$i++)
		
		  {
			for($n=0;$n<$num_row;$n++)
		
		 {
			 if($time_taken1[$n] == $time[$i])
			 {
			 echo "time taken";
			 break;
			 }
			 else 
			 {
				 echo "$time[$i]";
			 break;
			 }
		 }
	
		}



    
		}
		

  ?>

</html>